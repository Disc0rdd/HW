#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdbool.h>
#include <inttypes.h>
#include <math.h>

//sets the bit pos to the value. if value is == 0 it zeroes the bit if value !=0 it sets the bit

void setBit(uint64_t *val, int bit, int value)
{
    if(value)
    {
        *val |= ((uint64_t)1 << bit);
    }
    else
    {
        *val &= ~((uint64_t)1 << bit);
    }
}






    
int main(void)
{
   

uint64_t iTmp = 0;





    uint64_t attendance = 0ll;
    int option;
    while (1)
    {
        printf("1. Set attendance\n");
        printf("2. Clear attendance\n");
        printf("3. Attendance info\n");
        printf("4. Change attendance\n");
        printf("5. Exit\n");
        scanf("%d", &option);
        if (option == 1)
        {
            int a=0,b=0;
            printf("Choose the Bit and then the Value\n");
            scanf("%d",&a);
            scanf("%d",&b);
             setBit(&attendance,a,b);
        }
        else if (option == 2)
        {
            printf("Choose the Bit to eliminate\n");
            int a=0;
            scanf("%d",&a);
            setBit(&attendance,a,0);// to do
        }
        else if (option == 3)
        {
          for(int i = 0 ;i<64;i++)
            {
                iTmp = pow(2,i);

                    if(iTmp & attendance)
                        {
                        printf("bit %d is 1 \n",i);
                        }else{
                            printf("bit %d is 0 \n",i);
                        }
            }
             // to do
        }else if(option == 4){

for(int i = 0 ;i<64;i++)
            {
                iTmp = pow(2,i);

                    if(iTmp & attendance)
                        {
                        
                        setBit(&attendance,i,0);
                        }else{
                            
                            setBit(&attendance,i,1);
                        }
            }

        
        // to do
        }else if(option == 5){
            break;
        }
        
    }
    return 0;
}
