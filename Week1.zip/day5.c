#include <stdio.h>
#include <stdint.h>
#include <math.h>
#include <stdarg.h>


#define MAX(a, b, c) ( (a > b && a > c) ? a : (b > c) ? b : c )
#define MIN(a, b, c) ( (a < b && a < c) ? a : (b < c) ? b : c )
#define SETBIT(mask,nbit)   ((mask) |=  (1<<(nbit)))
#define CLEARBIT(mask,nbit) ((mask) &= ~(1<<(nbit)))
#define INVERSEBIT(mask,nbit)  ((mask) ^=  (1<<(nbit)))
#define CHECKBIT(mask,nbit) ((mask) &   (1<<(nbit)))
#define SWAP(a,b)( a = a ^ b , b = b ^ a , a = a ^ b)

int printer(size_t number,int* br){
size_t iTmp = 0;
*br=0;
    
 for(int i = 0 ;i<sizeof(size_t);i++)
            {
                iTmp = pow(2,i);
                    
                    if(iTmp & number)
                        {
                        printf("bit %d is 1 \n",i);
                        *br=*br+1;
                        
                        }else{
                            printf("bit %d is 0 \n",i);
                        }
            }
//printf("BR %d  \n",*br);
}

int triangleCalc(unsigned a,unsigned b,unsigned c,double* perimeter,double* area){

if(a < 0 || b < 0 || c < 0){
    printf("Sorry can't do that bud\n");
    perimeter=0;
    area=0;
    return 0;
}
double s = (a+b+c)/2;

*area = sqrt(s*(s-a)*(s-b)*(s-c));
*perimeter=a+b+c;
return 0;




}

unsigned onesCount(unsigned cnt,size_t size, ...)
{
int br=0;

size_t iTmp=0;
va_list args;
va_start(args, size);
int sum=0;
for(int i = 0 ;i<cnt;i++)
{
   printer(va_arg(args,size_t),&br);
   sum=sum+br;
    
               
                        
                
           
                printf("-------------------\n");
                printf("BR so far : %d \n",sum);
                
                printf("-------------------\n");
            }
            




}
double avgGet(int cnt, ...);
    

int main(void)
{
   
    //char *a = "b";
    //printf("numbers 3 4 5 6 7 8 avg is : %lf \n", avgGet(6,3,4,5,6,7,8));
    //printf("Type to convert :");
    //scanf("%c",a);
    //printf("\n");
    int a, b ,c;
    printf(" 3 numbers a b c \n");
    scanf("%d",&a);
    scanf("%d",&b);
    scanf("%d",&c);
    printf("THE BIGGEST IS : %d",MAX(a,b,c));
    printf("\n");
    printf("SWAPING \n A : %d AND B %d \n", a , b);
    SWAP(a,b);
    printf("SWAPPED \n A : %d AND B %d \n I AM NOT YELLING \n", a , b);
    int count=0;
    size_t size=8;
    onesCount(3,size,3,11,2);


    int g=0,h=0,j=0;
    double perimeter=0;
    double area=0;
    printf("Add 3 variables for the triangle\n");
    scanf("%d",&g);
    scanf("%d",&h);
    scanf("%d",&j);
    triangleCalc(g,h,j,&perimeter,&area);
    printf("Area : %lf ; Perimeter : %lf \n",area,perimeter);

    

   

    return 0;
}


double avgGet(int cnt, ...){

double sum=0;
va_list args;
va_start(args, cnt);
for (int i=0;i<cnt;i++){
    sum=sum+va_arg(args,int);
}

return (double)(sum/cnt);
}
