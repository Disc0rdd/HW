#include <stdio.h>
#include <stdint.h>


void swap(char *a,char *b){
char* test;
test = b;
b = a;
a = test;


}

int symloop(int count,char c,int br)
{

if(br != count){
printf("%c",c);
br++;

symloop(count,c,br);
}else{


    return 0;
}
}



int main()
{
   
   int n=0;
   printf("Choose N : ");
   scanf("%d",&n);

//a)
   for(int i=0;i<n;i++){
       for(int j=n;j>0;j--){
           printf("*");

       }
       printf("\n");
   }

    printf("------------\n");

    //b)
    char c='$';
  for(int i=0;i<n;i++){
       symloop(i+1,c,0);
               printf("\n");
           }

           printf("------------\n");

    //g)
    char* masiv[100];
    char news='*';
  
 int totalRowNo,row,space,symbol;
 totalRowNo = n;

 for(row = 1; row <=totalRowNo;row++)
 {
     for(space = 1;space <=(totalRowNo-row);space++)
     printf(" ");

     for(symbol = 1; symbol <= ((2*row)-1);symbol++)

     if( symbol != (((2*row))/2)){
     printf("*");
     
     }else{
        printf("|");
     }

     printf("\n");
 }

printf("------------\n");
 //v          
           for(int i=0;i<n;i++){
               for(int j=0;j<n;j++){
                   
                   if((j==0 || j==n-1) && (i==0 || i==n-1)  ){
                   printf("+");
                   }else if(j==0 || j==n-1){
                       printf("|");
                   }
                    
                   if (j!=0 && j!=n-1){
                      printf("-"); 
                   }
                   
                   

               }
               printf("\n");
           }
    
    return 0;
}
