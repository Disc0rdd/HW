#include <stdio.h>
#include <stdint.h>
#include <stdarg.h>

double avgGet(int cnt, ...);

void printNumber(char *a, int num){
    printf(" SIMPLY : %c",*a);
        if(a=="d"){



        }
        if(a=="o"){




        if(a=="x"){


        }
        if(a=="b"){
            printf("%d number in binary is : ",num);

            for(int i=0;num!=0;i++, num=(num/2)){
                printf(" %d",(num%2));


            }
        }
    }



        
        


}

int main()
{
    char *a = "b";
    printf("numbers 3 4 5 6 7 8 avg is : %lf \n", avgGet(6,3,4,5,6,7,8));
    printf("Type to convert :");
    //scanf("%c",a);
    //printf("\n");

    printNumber(a,15);

    return 0;
}


double avgGet(int cnt, ...){

double sum=0;
va_list args;
va_start(args, cnt);
for (int i=0;i<cnt;i++){
    sum=sum+va_arg(args,int);
}

return (double)(sum/cnt);
}
