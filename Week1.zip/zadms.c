#include <stdio.h>
#include <stdint.h>
#!/usr/bin/env bash



int main()
{
   

    

    
    return 0;
}
