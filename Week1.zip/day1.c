#include <stdio.h>
#include <math.h>

int main()

{

double r,h,l;
double V;
double pi=M_PI;


printf("R L H\n");
scanf("%lf",&r);
scanf("%lf",&l);
scanf("%lf",&h);



V=acos((r-h)/r)*r*r-(r-h)*(sqrt(2*r*h-h*h));


printf("The Value : %lf\n",V);

return 0;

}

