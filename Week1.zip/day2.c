#include <stdio.h>
#include <math.h>

// build-in compare operator
int floatCompare1(float a, float b){
    return a == b;
}

// fixed epsilon
int floatCompare2(float a, float b){
    return fabs(a - b) < 1.0e-5f;
}

// adaptive epsilon
int floatCompare3(float a, float b){
    return fabs(a - b) < 1.0e-5f * fmax(fabs(a), fabs(b));
}

//Accuracy of the machine, takes the first two cycles and makes an average error
// it will then remove the error from the final cycle to produce the correct value
// wasn't able to test with a lot of loat numbers if there are any errors i'd be happy to rethink the approach

double cutinaccuracy(int cycle,float increment,float a,float b)
{

float decider = fabs((a/cycle)-b);

//run 1 cycle

for(int i=0;i<1;i++);
{
    b=b+increment;
    printf("B: %f \n",b);
}

float decider2=fabs((a/(cycle)+increment)-b);

float trueerror = fabs(decider-decider2);

for(int i=0;i<cycle-1;i++){
b=b+increment;
printf("B: %f \n",b);
}

printf("Test removal of error \n A : %.30f \n B: %.30f \n True Error %.30f \n If Error was removed %.30f \n",a,b,trueerror,(b-(trueerror*cycle)));
return 0;
}

int main(void){
    float a = 1.1f;
    float b = 0.1f;
    
    //works if there is a loss downward, example above, if there is a problem with adding additional value it would need to be reconfigured 


    
    cutinaccuracy(10,0.1f,a,b);

    
    for (int i = 0; i < 22; i++, b += 0.1f);
    if (floatCompare1(a, b)){
        printf("== Equals\n");
    } else {
        printf("== Not equals\n");
    }
    if (floatCompare2(a, b)){
        printf("fixed E: Equals\n");
    } else {
        printf("fixed E: Not equals\n");
    }
    if (floatCompare3(a, b)){
        printf("Adaptive E: Equals\n");
    } else {
        printf("Adaptive E: Not equals\n");
    }
    return 0;
}