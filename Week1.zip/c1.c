#include <stdio.h>
#include <stdint.h>
#include <math.h>
#include <stdarg.h>



int printer(size_t number,int* br){
size_t iTmp = 0;
*br=0;
    
 for(int i = 0 ;i<64;i++)
            {
                iTmp = pow(2,i);
                    
                    if(iTmp & number)
                        {
                        printf("bit %d is 1 \n",i);
                        
                        *br=*br+1;
                        
                        }else{
                            printf("bit %d is 0 \n",i);
                        }
            }
//printf("BR %d  \n",*br);
}



size_t bitsNCount(unsigned cnt,size_t size, ...)
{
int br=0;
int truebr=0;

size_t iTmp=0;
va_list args;
va_start(args, size);
int sum=0;
for(int i = 0 ;i<cnt;i++)
{
   printer(va_arg(args,size_t),&br);
   sum=sum+br;
   if(br == size){
       truebr++;
   }
    
               
                        
                
           
                printf("-------------------\n");
                printf("BR so far : %d \n",truebr);
                
                printf("-------------------\n");
            }
            




}

    

int main(void)
{
   
    int count=0;
    size_t size=2;
    bitsNCount(4,size,0x0a,0xff,0,1);
    printf("-----------------------------\n");
    bitsNCount(3,8,0xff,0x13f1,0xaaaa);
    printf("-----------------------------\n");
    bitsNCount(5,10,0x0a,0xa0ff,0,10,0b1010111110111);


    

   

    return 0;
}
